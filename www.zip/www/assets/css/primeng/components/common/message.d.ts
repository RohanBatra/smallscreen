export interface Message {
    severity?: string;
    summary?: string;
    detail?: string;
    id?: any;
}
