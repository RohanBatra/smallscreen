export declare class ProgressSpinner {
    style: any;
    styleClass: string;
    strokeWidth: string;
    fill: string;
    animationDuration: string;
}
export declare class ProgressSpinnerModule {
}
