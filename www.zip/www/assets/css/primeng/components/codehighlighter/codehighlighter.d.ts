import { ElementRef, OnInit } from '@angular/core';
export declare class CodeHighlighter implements OnInit {
    el: ElementRef;
    constructor(el: ElementRef);
    ngOnInit(): void;
}
export declare class CodeHighlighterModule {
}
