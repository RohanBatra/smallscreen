export declare class UIMessage {
    severity: string;
    text: string;
    readonly icon: string;
}
export declare class MessageModule {
}
